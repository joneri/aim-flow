# AIM Flow 0.1.0-beta.4 · Beta

This is a technical beta for trusted, reviewed projects. It is not a general autonomous delivery service. Start with archive verification and read-only readiness. No model call, execution or deployment is authorized by installation.

## Before executing the bootstrap

Use Python 3.11+ on a POSIX filesystem. Obtain the expected bootstrap and archive pins through a separate trusted channel. The hashes below identify these bytes but do not authenticate an untrusted download by themselves.

- Bootstrap SHA-256: `7c81e140949f577cb698b75f2d5137561d367626ff95ac4692a5ae6f12dccffd`
- Controller archive SHA-256: `16a3a65e9db960764ef4503ec6fb0f0918675ec3c0de89c12a45d08e676ed7bf`
- Installed manifest SHA-256: `bed7ad9f0ee919b73a492c648226ed8f024a503732a99823da2389b700ce24b5`

After extracting, enter the `controller` directory. Check the bootstrap without executing it, using the independently trusted expected hash:

```sh
python3 -IBS -c 'import hashlib,sys; actual=hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest(); sys.exit(0 if actual == sys.argv[2] else "Bootstrap SHA-256 mismatch")' aim-ci-bootstrap.pyz EXPECTED_BOOTSTRAP_SHA256
```

Do not continue if the check fails. Then:

```sh
python3 -IBS aim-ci-bootstrap.pyz verify --archive aim-ci-control-0.1.0-beta.4.tar.gz --sha256 EXPECTED_ARCHIVE_SHA256
python3 -IBS aim-ci-bootstrap.pyz install --archive aim-ci-control-0.1.0-beta.4.tar.gz --sha256 EXPECTED_ARCHIVE_SHA256 --destination /absolute/path/to/new-private-controller
python3 -IBS /absolute/path/to/new-private-controller/aim-ci-control.py readiness --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

Unconfigured readiness normally exits **3** with `packageVerified: true` and `ready: false`. Exit **1** signals failure. Keep the installation outside your project. Project inspection additionally requires Git 2.54+ and its independently verified executable pin.

The historical `aim-ci` names are intentionally preserved. See [BETA-SCOPE.md](BETA-SCOPE.md), [LICENSE](LICENSE) and [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md). The original detailed guide and original release metadata remain intact in `controller/`. Detailed current source instructions: https://github.com/joneri/aim-flow/blob/main/docs/QUICKSTART.md
