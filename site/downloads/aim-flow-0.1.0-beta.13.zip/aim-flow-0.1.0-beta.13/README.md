# AIM Flow 0.1.0-beta.13 · Beta

This is a technical beta for trusted, reviewed projects. It is not a general autonomous delivery service. Start with archive verification and read-only readiness. No model call, execution or deployment is authorized by installation.

## Before executing the bootstrap

Use Python 3.11+ on a POSIX filesystem. Obtain the expected bootstrap and archive pins through a separate trusted channel. The hashes below identify these bytes but do not authenticate an untrusted download by themselves.

- Bootstrap SHA-256: `884311c0585b021f78f5db42d469a0d66157d4a2908343567b68bf1f390e7c05`
- Controller archive SHA-256: `2bc392d573750137f934aa3983cc8813e385e06cb433278212b376e37a7b48bd`
- Installed manifest SHA-256: `ecf50440dd1e8b09c95952683edcd90be224d8f8b42c77b6babe84e0107436af`

After extracting, enter the `controller` directory. Check the bootstrap without executing it, using the independently trusted expected hash:

```sh
python3 -IBS -c 'import hashlib,sys; actual=hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest(); sys.exit(0 if actual == sys.argv[2] else "Bootstrap SHA-256 mismatch")' aim-ci-bootstrap.pyz EXPECTED_BOOTSTRAP_SHA256
```

Do not continue if the check fails. Then:

```sh
python3 -IBS aim-ci-bootstrap.pyz verify --archive aim-ci-control-0.1.0-beta.13.tar.gz --sha256 EXPECTED_ARCHIVE_SHA256
python3 -IBS aim-ci-bootstrap.pyz install --archive aim-ci-control-0.1.0-beta.13.tar.gz --sha256 EXPECTED_ARCHIVE_SHA256 --destination /absolute/path/to/new-private-controller
python3 -IBS /absolute/path/to/new-private-controller/aim-ci-control.py readiness --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

Unconfigured readiness normally exits **3** with `packageVerified: true` and `ready: false`. Exit **1** signals failure. Keep the installation outside your project. Project inspection additionally requires Git 2.54+ and its independently verified executable pin.

The installation also includes `aim-flow.py deliver-api` for explicit Sol/xhigh patch proposals. Read the installed `docs/API-DELIVERY.md` before configuring it. A no-key preview is read-only; actual API use needs exact authorization and established campaign history. It also includes `onboard-api` for a separately approved source-cited assessment and project-local validation commands for reviewed npm stages. Read installed `docs/PROJECT-ONBOARDING.md` and `docs/PROJECT-VALIDATION.md`. An assessment is not execution permission. The macOS sandbox and Linux Docker adapters have separate prerequisites; no Docker startup, image/package download, platform qualification or deployment is authorized by installation.

Beta.13 adds the optional `run-codex` workflow and proposal-only `deliver-codex` route using an independently installed Codex CLI and existing eligible ChatGPT login. Read installed `docs/DELIVERY-BACKENDS.md`. Codex account usage is separate from API campaign accounting; USD cost and available quota are not inferred. Cloud dispatch is unavailable. Installation does not authorize account consumption, host tests or publication.

Archive schema 3 has an exact 105-file inventory in this release. Older beta.8 schema-3 archives have 53 files and need their own matching bootstrap. Preserve old installations, instances and budget history; do not mix bootstraps or silently migrate attempts.

The historical `aim-ci` names are intentionally preserved. See [BETA-SCOPE.md](BETA-SCOPE.md), [LICENSE](LICENSE) and [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md). The original detailed guide and original release metadata remain intact in `controller/`. Detailed current source instructions: https://github.com/joneri/aim-flow/blob/main/docs/QUICKSTART.md
