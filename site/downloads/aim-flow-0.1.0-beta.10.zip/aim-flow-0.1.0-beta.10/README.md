# AIM Flow 0.1.0-beta.10 · Beta

This is a technical beta for trusted, reviewed projects. It is not a general autonomous delivery service. Start with archive verification and read-only readiness. No model call, execution or deployment is authorized by installation.

## Before executing the bootstrap

Use Python 3.11+ on a POSIX filesystem. Obtain the expected bootstrap and archive pins through a separate trusted channel. The hashes below identify these bytes but do not authenticate an untrusted download by themselves.

- Bootstrap SHA-256: `923e58c8699c4becd7cc8fd9fe474412b26daf0b2898695fbc405d363073c35c`
- Controller archive SHA-256: `7e9879bd32d4ac3144dcc011659af65fad8661544e4fa6a3b03dc3879a7ab9a7`
- Installed manifest SHA-256: `5123d3bfdf47dd987293b5a324aa9cc34052c539f4b0600e8fa852b57fb12e15`

After extracting, enter the `controller` directory. Check the bootstrap without executing it, using the independently trusted expected hash:

```sh
python3 -IBS -c 'import hashlib,sys; actual=hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest(); sys.exit(0 if actual == sys.argv[2] else "Bootstrap SHA-256 mismatch")' aim-ci-bootstrap.pyz EXPECTED_BOOTSTRAP_SHA256
```

Do not continue if the check fails. Then:

```sh
python3 -IBS aim-ci-bootstrap.pyz verify --archive aim-ci-control-0.1.0-beta.10.tar.gz --sha256 EXPECTED_ARCHIVE_SHA256
python3 -IBS aim-ci-bootstrap.pyz install --archive aim-ci-control-0.1.0-beta.10.tar.gz --sha256 EXPECTED_ARCHIVE_SHA256 --destination /absolute/path/to/new-private-controller
python3 -IBS /absolute/path/to/new-private-controller/aim-ci-control.py readiness --manifest-sha256 EXPECTED_MANIFEST_SHA256
```

Unconfigured readiness normally exits **3** with `packageVerified: true` and `ready: false`. Exit **1** signals failure. Keep the installation outside your project. Project inspection additionally requires Git 2.54+ and its independently verified executable pin.

The installation also includes `aim-flow.py deliver-api` for explicit Sol/xhigh patch proposals. Read the installed `docs/API-DELIVERY.md` before configuring it. A no-key preview is read-only; actual API use needs exact authorization and established campaign history. It also includes `onboard-api` for a separately approved source-cited assessment and project-local validation commands for reviewed npm stages. Read installed `docs/PROJECT-ONBOARDING.md` and `docs/PROJECT-VALIDATION.md`. An assessment is not execution permission. The macOS sandbox and Linux Docker adapters have separate prerequisites; no Docker startup, image/package download, platform qualification or deployment is authorized by installation.

Archive schema 3 has an exact 100-file inventory in this release. Older beta.8 schema-3 archives have 53 files and need their own matching bootstrap. Preserve old installations, instances and budget history; do not mix bootstraps or silently migrate attempts.

The historical `aim-ci` names are intentionally preserved. See [BETA-SCOPE.md](BETA-SCOPE.md), [LICENSE](LICENSE) and [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md). The original detailed guide and original release metadata remain intact in `controller/`. Detailed current source instructions: https://github.com/joneri/aim-flow/blob/main/docs/QUICKSTART.md
